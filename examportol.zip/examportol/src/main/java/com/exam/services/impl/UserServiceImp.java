package com.exam.services.impl;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.entity.User;
import com.exam.entity.UserRole;
import com.exam.reposetory.RoleReposetory;
import com.exam.reposetory.UserReposetory;
import com.exam.services.UserService;
@Service
public class UserServiceImp implements UserService {
	@Autowired
	private UserReposetory userReposetory;
	@Autowired
	private RoleReposetory roleReposetory;

	@Override
	public User createUser(User user, Set<UserRole> userRoles) throws Exception {
		
		User local=this.userReposetory.findByUsername(user.getUsername());
		if(local!=null)
		{
			System.out.println("User is Already Register!!");
			throw new Exception("User is Already Register!!");
		}
		else
		{
			//create User
			
			for(UserRole ur:userRoles)
			{
				roleReposetory.save(ur.getRole());
			}
			user.getUserrole().addAll(userRoles);
			local=this.userReposetory.save(user);
			
		}
		
		return local;
	}

	//get user by username
	@Override
	public User getUser(String username) {
		
		return this.userReposetory.findByUsername(username);
	}

	
	//delete user by userid
	@Override
	public void deleteUser(Long userid) {
		 this.userReposetory.deleteById(userid);
		
	}

	@Override
	public User updateUser(String username) {
		// TODO Auto-generated method stub
		return this.userReposetory.findByUsername(username);
	}

	@Override
	public User saveOrUpdate(User user) {
		// TODO Auto-generated method stub
		return this.userReposetory.save(user);
	}

}
