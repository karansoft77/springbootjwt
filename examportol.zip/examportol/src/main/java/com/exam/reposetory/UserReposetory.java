package com.exam.reposetory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exam.entity.User;
@Repository
public interface UserReposetory extends JpaRepository<User, Long>{
	public User findByUsername(String username);

}
