package com.exam.entity;

public class JwtReponse {
	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public JwtReponse(String token) {
		super();
		this.token = token;
	}

	public JwtReponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
